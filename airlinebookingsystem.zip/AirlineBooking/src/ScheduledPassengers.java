
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class ScheduledPassengers extends javax.swing.JInternalFrame {
  String t;
DefaultTableModel model,model2;
    public ScheduledPassengers() {
        initComponents();
            t1.getColumnModel().getColumn(0).setPreferredWidth(15);
        t1.getColumnModel().getColumn(1).setPreferredWidth(25);
        t1.getColumnModel().getColumn(2).setPreferredWidth(50);
        t1.getColumnModel().getColumn(3).setPreferredWidth(60);
        t1.getColumnModel().getColumn(4).setPreferredWidth(60);
        getData();
    }
 public void getData()
    {
         model = (DefaultTableModel) t1.getModel();
         model.setRowCount(0);
         int counter = 0;
         Object rowData[] = new Object[9];
         if (ProjectDB.flight_desc_list.isEmpty()) {
            JOptionPane.showMessageDialog(this, "\t==> No Flight descriptions added yet <==");
        }
        for (ScheduledFlight scf : ProjectDB.scheduled_flight_list) {
                    int pNumber = Passenger.getSCFlightPassengersCount(scf.flight_number);
                    String pCount = (pNumber == scf.capacity) ? "Full(" + pNumber + ")" : Integer.toString(pNumber);
//                    rowData2[0] = ++counter;
                    ++counter;
                    rowData[0] = counter;
                    if(scf.flight_number == 0)
                    {
                        rowData[1] = "N.Y.S";
                    }
                    else{
                    rowData[1] = scf.flight_number;
                    }
                    if(scf.date.equals(""))
                    {
                        rowData[2] = "N.Y.S";
                    }
                    else{
                        rowData[2] = scf.date;
                    }
                    rowData[3] = scf.from;
                    rowData[4]= scf.to;
                    rowData[5] = scf.departure_time;
                    rowData[6] = scf.arrival_time;
                    rowData[7] = pCount;
                    model.addRow(rowData);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        t1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        t2 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setTitle("View Scheduled Passengers");

        jLabel1.setFont(new java.awt.Font("Liberation Sans", 1, 18)); // NOI18N
        jLabel1.setText("View/Cancel Scheduled Flight Passengers");

        t1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "FN", "Date", "From", "To", "Dept. Time", "Arrival Time", "Passengers"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        t1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                t1MousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(t1);

        t2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Name"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        t2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                t2MousePressed(evt);
            }
        });
        jScrollPane2.setViewportView(t2);

        jButton1.setText("Show Passenger List");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 670, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(176, 176, 176)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(208, 208, 208)
                        .addComponent(jButton1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(117, 117, 117)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 156, Short.MAX_VALUE)
                .addGap(12, 12, 12))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void t1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_t1MousePressed

        // TODO add your handling code here:
    }//GEN-LAST:event_t1MousePressed

    private void t2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_t2MousePressed

 

        // TODO add your handling code here:
    }//GEN-LAST:event_t2MousePressed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        int r = t1.getSelectedRow();
        model2 = (DefaultTableModel) t2.getModel();
         model2.setRowCount(0);
         int counter = 0;
         Object rowData[] = new Object[2];
        int data = (int) t1.getValueAt(r, 0);
        int flight_num = ProjectDB.scheduled_flight_list.get(data - 1).flight_number;
        Passenger.show_only_flight_no(flight_num);
        ArrayList<Passenger> output = new ArrayList<>();
        for (Passenger pa : ProjectDB.passenger_list) {
            if (pa.flight_number == flight_num)
                output.add(pa);
        }
        if (output.isEmpty()) {
            System.out.println("\t=> No Reservations added yet <=");
            JOptionPane.showMessageDialog(this, "\t=> No Reservations added yet <=");
            return;
        }

        for (Passenger p : output) {
            ++counter;
            rowData[0] = counter;
            rowData[1] = p.name;
            model2.addRow(rowData);
            System.out.printf("%5d | %-30s |\n", ++counter, p.name);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable t1;
    private javax.swing.JTable t2;
    // End of variables declaration//GEN-END:variables
}
