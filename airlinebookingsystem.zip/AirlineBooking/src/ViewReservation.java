
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class ViewReservation extends javax.swing.JInternalFrame {
  String t;
DefaultTableModel model; 
    public ViewReservation() {
        initComponents();
        getData();
    }
    public void getData()
    {
         model = (DefaultTableModel) t1.getModel();
         model.setRowCount(0);
         int counter = 0;
         Object rowData[] = new Object[3];
          if (ProjectDB.passenger_list.isEmpty()) {
            JOptionPane.showMessageDialog(this, "\t==> No Reservations added yet <==");
        }

        for (Passenger p : ProjectDB.passenger_list) {
            rowData[0] = ++counter;
            rowData[1] = p.flight_number;
            rowData[2] = p.name;
            System.out.printf("%5d | %5d | %-30s |\n", ++counter, p.flight_number, p.name);
            model.addRow(rowData);
        }
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        t1 = new javax.swing.JTable();

        setClosable(true);
        setIconifiable(true);
        setTitle("View/Cancel Reservations");

        jLabel1.setFont(new java.awt.Font("Liberation Sans", 1, 18)); // NOI18N
        jLabel1.setText("View/Delete Reservations");

        jLabel2.setText("*click on any flight to remove/delete them.");

        t1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "FN", "Name"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        t1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                t1MousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(t1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(119, 119, 119))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 18, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void t1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_t1MousePressed

        int r = t1.getSelectedRow();
        int data = (int) t1.getValueAt(r, 0);
        int input = JOptionPane.showConfirmDialog(null, "Do you like to cancel this reservation?");
        if(input == 0)
        {
             ProjectDB.passenger_list.remove(ProjectDB.passenger_list.get(data - 1));
             JOptionPane.showMessageDialog(this, "\t==> Reservation Cancelled. <==");
             getData();

        }

        // TODO add your handling code here:
    }//GEN-LAST:event_t1MousePressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable t1;
    // End of variables declaration//GEN-END:variables
}
