
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class AVRScheduledFlight extends javax.swing.JInternalFrame {

     String t;
DefaultTableModel model;
    public AVRScheduledFlight() {
        initComponents();
        t1.getColumnModel().getColumn(0).setPreferredWidth(15);
        t1.getColumnModel().getColumn(1).setPreferredWidth(25);
        t1.getColumnModel().getColumn(2).setPreferredWidth(50);
        t1.getColumnModel().getColumn(3).setPreferredWidth(60);
        t1.getColumnModel().getColumn(4).setPreferredWidth(60);
        t1.getColumnModel().getColumn(7).setPreferredWidth(30);
        getData();
    }
    public void getData()
    {
         model = (DefaultTableModel) t1.getModel();
         model.setRowCount(0);
         int counter = 0;
         Object rowData[] = new Object[9];
         if (ProjectDB.flight_desc_list.isEmpty()) {
            JOptionPane.showMessageDialog(this, "\t==> No Flight descriptions added yet <==");
        }
        for (ScheduledFlight scf : ProjectDB.scheduled_flight_list) {
                    int pNumber = Passenger.getSCFlightPassengersCount(scf.flight_number);
                    String pCount = (pNumber == scf.capacity) ? "Full(" + pNumber + ")" : Integer.toString(pNumber);
//                    rowData2[0] = ++counter;
                    ++counter;
                    rowData[0] = counter;
                    if(scf.flight_number == 0)
                    {
                        rowData[1] = "N.Y.S";
                    }
                    else{
                    rowData[1] = scf.flight_number;
                    }
                    if(scf.date.equals(""))
                    {
                        rowData[2] = "N.Y.S";
                    }
                    else{
                        rowData[2] = scf.date;
                    }
                    rowData[3] = scf.from;
                    rowData[4]= scf.to;
                    rowData[5] = scf.departure_time;
                    rowData[6] = scf.arrival_time;
                    rowData[7] = scf.capacity;
                    model.addRow(rowData);
        }
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        t1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setTitle("View/Cancel the Schedule Flight");

        t1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Flight No.", "Date", "From", "To", "Dept. Time", "Arrival Time", "Capacity"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        t1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                t1MousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(t1);

        jLabel2.setText("*click on any flight to remove/delete them.");

        jLabel1.setFont(new java.awt.Font("Liberation Sans", 1, 18)); // NOI18N
        jLabel1.setText("View/Delete Scheduled Flight Description");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(248, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(159, 159, 159))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(64, 64, 64))))
            .addComponent(jScrollPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 204, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void t1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_t1MousePressed

       int r = t1.getSelectedRow();
        int data = (int) t1.getValueAt(r, 0);
        int input = JOptionPane.showConfirmDialog(null, "Do you like to cancel this scheduled flight?");
        if(input == 0)
        {
            ProjectDB.scheduled_flight_list.remove(ProjectDB.scheduled_flight_list.get(data - 1));
            JOptionPane.showMessageDialog(this, "Scheduled Flight Cancelled.");
            getData();
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_t1MousePressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable t1;
    // End of variables declaration//GEN-END:variables
}
