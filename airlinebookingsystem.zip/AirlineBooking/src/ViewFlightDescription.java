
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class ViewFlightDescription extends javax.swing.JInternalFrame {
  String t;
DefaultTableModel model; 
    public ViewFlightDescription() {
        initComponents();
        getData();
    }
public void getData()
    {
         model = (DefaultTableModel) t1.getModel();
         model.setRowCount(0);
         int counter = 0;
         Object rowData[] = new Object[6];
          if (ProjectDB.flight_desc_list.isEmpty()) {
            System.out.println("\t==> No Flight descriptions added yet <==");
        }
         for (FlightDescription fd : ProjectDB.flight_desc_list) {
                    ++counter;
                    rowData[0] = counter;
                    rowData[1] = fd.from;
                    rowData[2]= fd.to;
                    rowData[3] = fd.departure_time;
                    rowData[4] = fd.arrival_time;
                    rowData[5] = fd.capacity;
                    model.addRow(rowData);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        t1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setTitle("View & Delete Flights");

        t1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "From", "To", "Dept. Time", "Arrival Time", "Capacity"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        t1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                t1MousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(t1);

        jLabel1.setFont(new java.awt.Font("Liberation Sans", 1, 18)); // NOI18N
        jLabel1.setText("View Flight Description/Add Scheduled Flights");

        jLabel2.setText("*click on any flight to add for scheduled flight or remove/delete them.");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 712, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(146, 146, 146))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(84, 84, 84))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void t1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_t1MousePressed
 int r = t1.getSelectedRow();
        int data = (int) t1.getValueAt(r, 0);
        String[] options = new String[3];
        FlightDescription fd = ProjectDB.flight_desc_list.get(data - 1);
        options[0] = "Add Scheduled Date";
        options[1] = "Remove this Flight";
        options[2] = "Cancel";
        int a = JOptionPane.showOptionDialog(this, "Choose the action for this flight", "Task", 0, JOptionPane.INFORMATION_MESSAGE, null, options, null);
        if(a == 0)
        {
            String input = JOptionPane.showInputDialog(this,"Enter the Date(YYY/MM/DD): ");
            int prevLen = ProjectDB.scheduled_flight_list.size();
            try {
                ProjectDB.add(new ScheduledFlight(fd, input));
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,ex);
            }
            int afterLen = ProjectDB.scheduled_flight_list.size();
            if (prevLen != afterLen) {
                System.out.println("Scheduled " + input + " for flight : " + fd.from + " -> " + fd.to + "\n");
           JOptionPane.showMessageDialog(this, "Scheduled " + input + " for flight : " + fd.from + " -> " + fd.to + "\n");
            }

        }
        else if(a == 1)
        {
            ProjectDB.flight_desc_list.remove(ProjectDB.flight_desc_list.get(data - 1));
            JOptionPane.showMessageDialog(this, "Deleted the Flight Description.");
            getData();
        }
        else{
            return;
        }  

        // TODO add your handling code here:
    }//GEN-LAST:event_t1MousePressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable t1;
    // End of variables declaration//GEN-END:variables
}
