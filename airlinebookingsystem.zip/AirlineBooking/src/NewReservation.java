
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class NewReservation extends javax.swing.JInternalFrame {
    DefaultTableModel model;
    DefaultTableModel model2;
    int count;
    Person p;
    ScheduledFlight scf;

    public NewReservation() {
        initComponents();
        t1.getColumnModel().getColumn(0).setPreferredWidth(15);
        t2.getColumnModel().getColumn(0).setPreferredWidth(10);
        t2.getColumnModel().getColumn(1).setPreferredWidth(10);
        t2.getColumnModel().getColumn(5).setPreferredWidth(15);
        b2.setEnabled(false);
        b3.setEnabled(false);
        getData();
    }
     public void getData()
    {
        count = 0;
         model = (DefaultTableModel) t1.getModel();
         model2 = (DefaultTableModel) t2.getModel();
         model.setRowCount(0);
         model2.setRowCount(0);
         int counter = 0;
         Object rowData[] = new Object[3];
         Object rowData2[] = new Object[6];
         if (ProjectDB.person_list.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Kindly add the Customer first");
            return;
        }
         else{
            for (Person p : ProjectDB.person_list) {
                rowData[0] = ++counter;
                rowData[1] = p.name;
                rowData[2] = p.address;
                model.addRow(rowData);
            }
            if (ProjectDB.scheduled_flight_list.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Kindly add the Scheduled Flight first");
                return;
            }
            else{
                for (ScheduledFlight scf : ProjectDB.scheduled_flight_list) {
                    int pNumber = Passenger.getSCFlightPassengersCount(scf.flight_number);
                    String pCount = (pNumber == scf.capacity) ? "Full(" + pNumber + ")" : Integer.toString(pNumber);
//                    rowData2[0] = ++counter;
                    ++count;
                    rowData2[0] = count;
                    rowData2[1] = scf.flight_number;
                    rowData2[2] = scf.date;
                    rowData2[3] = scf.from + " - " +scf.to;
                    rowData2[4] = scf.departure_time +" - " +scf.arrival_time;
                    rowData2[5] = pCount;
                    model2.addRow(rowData2);
        }
           
        }
         
    }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        t1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        t2 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        b1 = new javax.swing.JButton();
        b2 = new javax.swing.JButton();
        b3 = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setResizable(true);
        setTitle("Add Reservation");

        jLabel1.setFont(new java.awt.Font("Liberation Sans", 1, 18)); // NOI18N
        jLabel1.setText("Make a New Reservation");

        t1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Name", "Address"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        t1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                t1MousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(t1);

        t2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Index", "Flight No.", "Date", "From - To", "Time", "Capacity"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        t2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                t2MousePressed(evt);
            }
        });
        jScrollPane2.setViewportView(t2);

        jLabel2.setFont(new java.awt.Font("Liberation Sans", 1, 15)); // NOI18N
        jLabel2.setText("Customers");

        jLabel3.setFont(new java.awt.Font("Liberation Sans", 1, 15)); // NOI18N
        jLabel3.setText("Scheduled Flights");

        b1.setText("Select");
        b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b1ActionPerformed(evt);
            }
        });

        b2.setText("Select");
        b2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2ActionPerformed(evt);
            }
        });

        b3.setText("Confirm Booking");
        b3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(74, 74, 74)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 255, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(161, 161, 161))
            .addGroup(layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(b1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(b2)
                .addGap(179, 179, 179))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(164, 164, 164)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(179, 179, 179)
                        .addComponent(b3)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 179, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(b1)
                    .addComponent(b2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(b3)
                .addContainerGap(11, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void t1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_t1MousePressed


        // TODO add your handling code here:
    }//GEN-LAST:event_t1MousePressed

    private void t2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_t2MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_t2MousePressed

    private void b1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b1ActionPerformed
int r = t1.getSelectedRow();
int data = (int) t1.getValueAt(r, 0);
p = ProjectDB.person_list.get(data - 1);
//System.out.print(p);
b1.setEnabled(false);
b2.setEnabled(true);
b3.setEnabled(false);

    }//GEN-LAST:event_b1ActionPerformed

    private void b2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2ActionPerformed

int r = t2.getSelectedRow();
int data = (int) t2.getValueAt(r, 0);
scf = ProjectDB.scheduled_flight_list.get(data-1);
b3.setEnabled(true);
b1.setEnabled(false);
b2.setEnabled(false);
        // TODO add your handling code here:
    }//GEN-LAST:event_b2ActionPerformed

    private void b3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b3ActionPerformed
if (scf.capacity == Passenger.getSCFlightPassengersCount(scf.flight_number)) {
    System.out.println("This flight is at maximum capacity.");
    JOptionPane.showMessageDialog(null,"This flight is at maximum capacity.");
    return;
   }
else{
    
    int prevLen = ProjectDB.passenger_list.size();
    try {
        ProjectDB.add(new Passenger(p, scf.flight_number));
    }
    catch (Exception ex) {
        System.out.println("ERROR : FILE NOT FOUND !");
    }
    int afterLen = ProjectDB.passenger_list.size();
    if (prevLen != afterLen) {
        JOptionPane.showMessageDialog(null, "Reservation completed : " + p.name + " (" + scf.from + " -> " + scf.to + ")\n");
    }
    b3.setEnabled(false);
    b1.setEnabled(true);
    b2.setEnabled(false);
        getData();
}
        // TODO add your handling code here:
    }//GEN-LAST:event_b3ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b1;
    private javax.swing.JButton b2;
    private javax.swing.JButton b3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable t1;
    private javax.swing.JTable t2;
    // End of variables declaration//GEN-END:variables
}
